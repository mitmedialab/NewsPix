// set this in newspix.js as well
//var SERVER_URL = "http://127.0.0.1:5000"; 
 var SERVER_URL = "http://dev.newspix.today";
